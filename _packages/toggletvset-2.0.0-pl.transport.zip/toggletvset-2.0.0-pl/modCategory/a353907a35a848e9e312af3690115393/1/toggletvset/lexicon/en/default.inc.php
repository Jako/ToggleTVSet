<?php
/**
 * Default Lexicon Entries for ToggleTVSet
 *
 * @package toggletvset
 * @subpackage lexicon
 */

$_lang['toggletvset'] = 'Toggle TV';
$_lang['toggletvset.package'] = 'ToggleTVSet';
